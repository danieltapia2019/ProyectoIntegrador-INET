<?php
//DESCOMENTAR
//echo __DIR__;//ejecutar y copiar la ruta y asignarla a $BASE_DIR para el correcto funcionamiento de rutas
$BASE_DIR = "C:\xampp\htdocs\ProyectoIntegrador-INET";//ruta para includes necesarios


//$partesruta = pathinfo($_SERVER['REQUEST_URI']);
//echo "https://".$_SERVER["HTTP_HOST"].$partesruta["dirname"]."/"; //mismo procedimiento que con la $BASE_DIR solo que se lo asignamos a la $BASE_URL
$BASE_URL = "https://localhost/ProyectoIntegrador-INET";

 ?>
